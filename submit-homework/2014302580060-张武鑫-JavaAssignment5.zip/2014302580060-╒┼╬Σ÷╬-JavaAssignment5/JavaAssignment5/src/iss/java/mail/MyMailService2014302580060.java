package iss.java.mail;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class MyMailService2014302580060 implements IMailService {
	/**
     * 发送邮件的props文件
     */
    private final transient Properties sendprops = System.getProperties();
    /**
     * 接受邮件的props文件
     */
    private final transient Properties reciprops = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private transient MailAuthenticator authenticator;
    /**
     * 发送时邮箱session
     */
    private transient Session sendSession;
    /**
     * 接收时邮箱session
     */
    private transient Session reciSession;
    /**
     * 接收时邮箱store
     */
    private transient Store store;
    /**
     * inbox内邮件数
     */
    private transient int mailCount = 0;
    
    
    
	/**
     * 初始化并连接所有的邮件服务器
     * @throws MessagingException 初始化或连接异常
     */
	@Override
	public void connect() throws MessagingException {
		// TODO 自动生成的方法存根
		// 初始化reciprops
		reciprops.put("mail.store.protocol", "imap");
		reciprops.put("mail.imap.host", "imap.139.com");
		reciprops.put("mail.imap.port", 143);
		//reciprops.put("mail.imap.ssl.enable", true);
        // 验证
        authenticator = new MailAuthenticator("zwxjava@139.com", "a13579");
        reciSession = Session.getInstance(reciprops, authenticator);
        //获取store
        store = reciSession.getStore();
        store.connect();
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);
        mailCount = folder.getMessageCount();
        folder.close(false);
        // 初始化sendprops
     	sendprops.put("mail.smtp.auth", "true");
     	sendprops.put("mail.smtp.host", "smtp.139.com");
     	//sendprops.put("mail.smtp.port", 587);
     	//sendprops.put("mail.smtp.ssl.enable", true);
     	//sendprops.put("mail.smtp.starttls.enable", true);
     	//sendprops.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
     	//sendprops.put("mail.smtp.socketFactory.fallback", "false");
     	//sendprops.put("mail.smtp.protocol.socketFactory.port", 587);
     	
        
        
        
        
        
        
        
        
	}

	/**
     * 发送单封邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO 自动生成的方法存根
		// 创建session
        sendSession = Session.getInstance(sendprops, authenticator);
		// 创建mime类型邮件
        final MimeMessage message = new MimeMessage(sendSession);
        // 设置发信人
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        // 设置收件人
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // 发送
        Transport.send(message);
	}

	/**
     * 询问服务器是否有新邮件到达
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */
	@Override
	public boolean listen() throws MessagingException {
		// TODO 自动生成的方法存根
		// 创建session
        reciSession = Session.getInstance(reciprops, authenticator);
        store.close();
        store = reciSession.getStore();
        store.connect();
		Folder folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		int newMailCount = folder.getMessageCount();
		if( newMailCount != mailCount )
		{
			mailCount = newMailCount;
			folder.close(false);
			return true;
		}
		folder.close(false);
		return false;
	}

	/**
     * 接收自动回复的内容，并转换为字符串
     * 注：用你能想到的任意方法寻找回复邮件均可，并不一定要用到这两个参数
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO 自动生成的方法存根
		reciSession = Session.getInstance(reciprops, authenticator);
        store.close();
        store = reciSession.getStore();
        store.connect();
		// 获得邮箱内的邮件夹Folder对象，以"只读"打开
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_WRITE);

        Message[] messages = folder.getMessages(1,1);

        int mailCounts = messages.length;
        for(int i = 0; i < mailCounts; i++) {

            String Sub = messages[i].getSubject();
            System.out.println(Sub);
            if( Sub.equals(subject.replace('：', ':')) )
            {
            	//String from = (messages[i].getFrom()[0]).toString();
            	//folder.close(false);
            	StringBuffer content = new StringBuffer();
            	getMailTextContent((MimeMessage)messages[i],content);
            	return content.toString();
            	
            }

            
            
         
        }
        folder.close(false);
		return null;
	}
	
	/** 
     * 获得邮件文本内容 
     * @param part 邮件体 
     * @param content 存储邮件文本内容的字符串 
     * @throws MessagingException 
     * @throws IOException 
     */  
    public static void getMailTextContent(Part part, StringBuffer content) throws MessagingException, IOException {  
        //如果是文本类型的附件，通过getContent方法可以取到文本内容，但这不是我们需要的结果，所以在这里要做判断  
        boolean isContainTextAttach = part.getContentType().indexOf("name") > 0;   
        if (part.isMimeType("text/*") && !isContainTextAttach) {  
            content.append(part.getContent().toString());  
        } else if (part.isMimeType("message/rfc822")) {   
            getMailTextContent((Part)part.getContent(),content);  
        } else if (part.isMimeType("multipart/*")) {  
            Multipart multipart = (Multipart) part.getContent();  
            int partCount = multipart.getCount();  
            for (int i = 0; i < partCount; i++) {  
                BodyPart bodyPart = multipart.getBodyPart(i);  
                getMailTextContent(bodyPart,content);  
            }  
        }  
    }  

}
